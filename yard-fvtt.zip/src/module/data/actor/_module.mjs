
import ChessData from "./chess.mjs";
import HeroData from "./hero.mjs";

export { ChessData, HeroData };
