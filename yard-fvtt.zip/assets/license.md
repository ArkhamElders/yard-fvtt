Licenses by directory

chess: Art by Skoll under CC BY 3.0
