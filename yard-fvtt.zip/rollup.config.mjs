export default {
  input: "./uts.mjs",
  output: {
    file: "./public/uts.mjs",
    format: "esm"
  }
};
